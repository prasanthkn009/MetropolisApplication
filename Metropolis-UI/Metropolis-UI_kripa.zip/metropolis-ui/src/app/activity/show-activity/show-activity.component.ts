import { Component, OnInit } from '@angular/core';
import { ApiService} from 'src/app/api.service'


@Component({
  selector: 'app-show-activity',
  templateUrl: './show-activity.component.html',
  styleUrls: ['./show-activity.component.css']
})
export class ShowActivityComponent implements OnInit {

  constructor(private service:ApiService) { }

  Activity:any=[];

  ngOnInit(): void {
    this.refreshActivityList();
    
  }

  refreshActivityList(){
    this.service.getActivityList().subscribe(data=>{
      this.Activity = data;
  });
  }

}