import { Component } from '@angular/core';
import { ApiService } from './api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'meteropolis';
  contact: any;
  constructor(private api: ApiService){}
  ngOnInit(): void {
    this.api.getActivity('https://localhost:44335/api/contact').subscribe(response=>{
      this.contact=response;
      console.log(this.contact);
    });

  }
}

