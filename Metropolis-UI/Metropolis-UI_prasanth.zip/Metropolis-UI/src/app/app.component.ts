import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<addactivity></addactivity><activities></activities>'
})
export class AppComponent {
  title = 'Metropolis-UI';
}
