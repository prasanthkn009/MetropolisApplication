import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity',
  template: '<app-show-activity></app-show-activity>',
  styleUrls: ['./activity.component.css']
})
export class ActivityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
